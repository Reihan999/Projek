package com.empty.dicodingevent.database

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize


@Entity
@Parcelize
data class FavoriteEvent(
    @PrimaryKey(autoGenerate = false)
    var id: String = "",
    var name: String = "",
    var mediaCover: String? = null,
    var host: String? = "",
    var time: String? ="",
    var registrants: String? ="",
    var remainingQuota: String?,
    var description: String?="",
    var link: String? ="",
    var summary: String? ="",
    var category: String?="",
) : Parcelable


