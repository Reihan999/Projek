package com.empty.dicodingevent.ui.finish

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.empty.dicodingevent.data.response.EventResponse
import com.empty.dicodingevent.databinding.FragmentFinishedBinding
import com.empty.dicodingevent.ui.MainViewModel
import com.empty.dicodingevent.ui.MainViewModelFactory
import com.empty.dicodingevent.ui.ReviewAdapter
import com.empty.dicodingevent.ui.detail.DetailActivity
import com.empty.dicodingevent.ui.setting.SettingPreferences
import com.empty.dicodingevent.ui.setting.dataStore
import com.google.android.material.snackbar.Snackbar

class FinishedFragment : Fragment() {

    private var _binding: FragmentFinishedBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ReviewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinishedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inisialisasi ViewModel menggunakan MainViewModelFactory dengan repository EventResponse
        val repository = EventResponse() // Pastikan ini diinisialisasi dengan benar sesuai repository Anda
//        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        val pref = SettingPreferences.getInstance(requireContext().dataStore)
        viewModel = ViewModelProvider(this, MainViewModelFactory(pref)).get(
            MainViewModel::class.java
        )

        initializeRecyclerView()

        viewModel.finishedEvents.observe(viewLifecycleOwner) { events ->
            adapter.submitList(events)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            displayLoadingIndicator(loading)
        }

        viewModel.errorMessage.observe(viewLifecycleOwner) { message ->
            message?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
            }
        }

        // Fetch finished events
        viewModel.fetchEvents(active = 0)
    }

    private fun initializeRecyclerView() {
        adapter = ReviewAdapter(requireContext()) { selectedEvent ->
            val detailIntent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("event", selectedEvent)
            }
            startActivity(detailIntent)
        }

        binding.recycleApiFinish.layoutManager = LinearLayoutManager(context)
        binding.recycleApiFinish.adapter = adapter
    }

    private fun displayLoadingIndicator(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
