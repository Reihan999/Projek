package com.empty.dicodingevent.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface FavoriteEventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(event: FavoriteEvent)

    @Update
    fun update(event: FavoriteEvent)

    @Delete
    fun delete(event: FavoriteEvent)


    @Query("DELETE FROM FavoriteEvent WHERE id = :id")
    suspend fun deleteEventById(id : Int)

    @Query("SELECT COUNT(*) FROM FavoriteEvent WHERE id = :eventId")
    suspend fun isFavorite(eventId: String): Int

    @Query("SELECT * FROM FavoriteEvent")
    fun getFavoriteEvents(): LiveData<List<FavoriteEvent>>


}