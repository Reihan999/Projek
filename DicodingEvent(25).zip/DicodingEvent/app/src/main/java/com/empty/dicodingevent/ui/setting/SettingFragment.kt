package com.empty.dicodingevent.ui.setting

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import com.empty.dicodingevent.R
import com.empty.dicodingevent.ui.MainViewModel
import com.empty.dicodingevent.ui.MainViewModelFactory
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingFragment : Fragment() {
    private val viewModel: MainViewModel by viewModels()
    private lateinit var switchTheme: SwitchMaterial

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_setting, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        switchTheme = view.findViewById(R.id.switch_theme)

        val pref = SettingPreferences.getInstance(requireContext().dataStore)
        val mainViewModel = ViewModelProvider(this, MainViewModelFactory(pref)).get(MainViewModel::class.java)


        // Observe the theme setting
        mainViewModel.getThemeSetting().observe(viewLifecycleOwner) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                switchTheme.isChecked = true
            } else {
                switchTheme.isChecked = false
            }
        }

        // Set listener for changing the dark mode
        switchTheme.setOnClickListener {
            val isDarkModeActive = switchTheme.isChecked
            mainViewModel.saveThemeSetting(isDarkModeActive)
        }
    }
}
