package com.empty.dicodingevent.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.empty.dicodingevent.R
import com.empty.dicodingevent.data.response.EventResponse
import com.empty.dicodingevent.databinding.FragmentHomeBinding
import com.empty.dicodingevent.ui.MainViewModel
import com.empty.dicodingevent.ui.MainViewModelFactory
import com.empty.dicodingevent.ui.ReviewAdapter
import com.empty.dicodingevent.ui.detail.DetailActivity
import com.empty.dicodingevent.ui.setting.SettingPreferences
import com.empty.dicodingevent.ui.setting.dataStore
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: MainViewModel
    private lateinit var ongoingEventAdapter: ReviewAdapter
    private lateinit var completedEventAdapter: ReviewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Pastikan Anda menginisialisasi ViewModel dengan benar
        val pref = SettingPreferences.getInstance(requireContext().dataStore)
        viewModel = ViewModelProvider(this, MainViewModelFactory(pref)).get(
            MainViewModel::class.java
        )

        initializeRecyclerViews()

        // Mengambil data events
        viewModel.fetchEvents(1) // Ongoing Events
        viewModel.fetchEvents(0) // Completed Events

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.activeEvents.observe(viewLifecycleOwner) { events ->
            ongoingEventAdapter.submitList(events)
        }

        viewModel.finishedEvents.observe(viewLifecycleOwner) { events ->
            completedEventAdapter.submitList(events)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            displayLoadingIndicator(loading)
        }

        viewModel.errorMessage.observe(viewLifecycleOwner) { message ->
            message?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun initializeRecyclerViews() {
        ongoingEventAdapter = ReviewAdapter(requireContext()) { event ->
            val detailIntent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("event_id", event.id)
            }
            startActivity(detailIntent)
        }

        binding.recyclerViewActiveEvents.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewActiveEvents.adapter = ongoingEventAdapter

        completedEventAdapter = ReviewAdapter(requireContext()) { event ->
            val detailIntent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("event_id", event.id)
            }
            startActivity(detailIntent)
        }

        binding.recyclerViewFinishedEvents.layoutManager = LinearLayoutManager(context)
        binding.recyclerViewFinishedEvents.adapter = completedEventAdapter
    }

    private fun displayLoadingIndicator(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
