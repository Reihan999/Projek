package com.empty.dicodingevent.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.empty.dicodingevent.data.response.EventResponse
import com.empty.dicodingevent.data.response.ListEventsItem
import com.empty.dicodingevent.data.retrofit.ApiConfig
import com.empty.dicodingevent.ui.setting.SettingPreferences
import kotlinx.coroutines.launch

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class MainViewModel(private val pref: SettingPreferences) : ViewModel() {

    private val _activeEvents = MutableLiveData<List<ListEventsItem>>()
    val activeEvents: LiveData<List<ListEventsItem>> = _activeEvents

    private val _finishedEvents = MutableLiveData<List<ListEventsItem>>()
    val finishedEvents: LiveData<List<ListEventsItem>> = _finishedEvents

    private val _searchResults = MutableLiveData<List<ListEventsItem>>()
    val searchResults: LiveData<List<ListEventsItem>> = _searchResults

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage



    fun fetchEvents(active: Int) {
        _isLoading.value = true
        _errorMessage.value = null
        val client = ApiConfig.create().getEvents(active)
        client.enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    when (active) {
                        1 -> _activeEvents.value = response.body()?.listEvents ?: emptyList()
                        0 -> _finishedEvents.value = response.body()?.listEvents ?: emptyList()
                    }
                } else {
                    _errorMessage.value = "Terjadi kesalahan: ${response.message()}"
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                _isLoading.value = false
                handleError(t)
            }
        })
    }

    private fun handleError(t: Throwable) {
        val message = when (t) {
            is UnknownHostException -> "Maaf, Internet lambat atau terputus"
            is SocketTimeoutException -> "Koneksi Internet Anda sangat lambat"
            else -> "Telah terjadi kesalahan: ${t.localizedMessage}"
        }
        _errorMessage.value = message
        Log.e("MainViewModel", "onFailure: ${t.message}")
    }
    fun getThemeSetting() : LiveData<Boolean> {
        return pref.getThemeSetting().asLiveData()
    }

    fun saveThemeSetting(isDarkModeActive: Boolean) {
            viewModelScope.launch {
                pref.saveThemeSetting(isDarkModeActive)
            }
        }
    }


